# Firmware

`aqi_voc_logger/aqi_voc_logger.ino` reads an SGP30 (TVOC, eCO2) and a GP2Y1010 dust sensor on an ESP32, serves a local web page, and logs to Google Sheets every 35 s.

## Setup
1. Install the Arduino IDE and the ESP32 board package. Install the "Adafruit SGP30 Sensor" library.
2. In `aqi_voc_logger/`, copy `secrets.example.h` to `secrets.h` and fill in your WiFi name, password and Google Apps Script `/exec` URL.
3. Select board "DOIT ESP32 DEVKIT V1", upload at 115200 baud.

## Wiring
| Sensor | ESP32 |
|---|---|
| SGP30 SDA / SCL | GPIO21 / GPIO22 |
| GP2Y1010 LED (pin 3) | GPIO25 |
| GP2Y1010 Vo (pin 5) | GPIO34, through a 10k/20k divider |

## Notes
- This sketch covers the SGP30 and dust sensor. The MQ135 and SCD30 readings in the data folder came from other versions of the sketch.
- The dust zero voltage (`DUST_ZERO_V`) must be calibrated in clean air.
- Use the Apps Script `/exec` URL (not `/echo`) with `HTTPC_STRICT_FOLLOW_REDIRECTS`.
